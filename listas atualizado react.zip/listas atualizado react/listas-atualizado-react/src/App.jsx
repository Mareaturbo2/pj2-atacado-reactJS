import ListasPage from './pages/ListasPage';

function App() {
  return <ListasPage />;
}

export default App;

