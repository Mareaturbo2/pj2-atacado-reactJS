import '../styles/style.css';

export default function Assistente() {
  return (
    <section className="assistente-section">
      <div className="assistente-content">
        <div className="assistente-imagem">
          <img src="/Tacadinho.png" alt="Tacadinho" />
        </div>
        <div className="assistente-texto">
          <h2>Tacadinho: Seu Assistente de Compras</h2>
          <p>Descubra nosso assistente Tacadinho, pronto para ajudar você a escolher os melhores presentes e montar sua lista com facilidade.</p>
          <button className="btn-tacadinho">Fale com o Tacadinho</button>
        </div>
      </div>
    </section>
  );
}