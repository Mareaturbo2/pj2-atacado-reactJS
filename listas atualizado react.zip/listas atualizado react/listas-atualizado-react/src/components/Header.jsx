import '../styles/style.css';

export default function Header() {
  return (
    <header className="top-header">
      <div className="top-content">
        <div className="buttons">
          <button className="btn-green">Meu Perfil</button>
          <button className="btn-red">Fale Conosco</button>
        </div>
        <nav className="nav-menu">
          <a href="#">Home</a>
          <a href="quemsomos.html">Quem Somos</a>
          <a href="#">Produtos</a>
          <a href="listas.html">Listas</a>
        </nav>
        <div className="logo">
          <img src="/Logo CMYK - Atacado dos Presentes - Horizontal.png" alt="Logo Atacado dos Presentes" />
        </div>
      </div>
    </header>
  );
}