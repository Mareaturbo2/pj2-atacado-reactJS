import '../styles/style.css';

export default function CriarLista() {
  return (
    <section className="criar-lista">
      <h2>Crie listas personalizadas e compartilhe com quem quiser!</h2>
      <p>Escolha os itens desejados, personalize detalhes e compartilhe com amigos e familiares para facilitar a escolha do presente perfeito.</p>
      <button className="btn-green">+ Criar Lista</button>
      <div className="listas-criadas">
        <button className="btn-lista">Lista de Casamento</button>
        <button className="btn-lista">Lista de Aniversário</button>
        <button className="btn-lista">Lista de Chá de Bebê</button>
        <button className="btn-lista">Lista de Formatura</button>
      </div>
    </section>
  );
}