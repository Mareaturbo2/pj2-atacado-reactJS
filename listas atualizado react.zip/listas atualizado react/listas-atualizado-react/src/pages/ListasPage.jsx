import Header from '../components/Header';
import CriarLista from '../components/CriarLista';
import Assistente from '../components/Assistente';
import BuscarLista from '../components/BuscarLista';
import Footer from '../components/Footer';
import '../styles/style.css';

export default function ListasPage() {
  return (
    <>
      <Header />
      <main className="container">
        <CriarLista />
        <Assistente />
        <BuscarLista />
      </main>
      <Footer />
    </>
  );
}
